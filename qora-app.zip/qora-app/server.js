// QORA backend: zero dependencies (Node 18+). Run: node server.js
const http=require("http"),fs=require("fs"),path=require("path");
const PORT=process.env.PORT||3000;
const R=p=>JSON.parse(fs.readFileSync(path.join(__dirname,"data",p),"utf8"));
const seed=R("seed.json"), staff=R("staff.json");
const DBF=path.join(__dirname,"data","db.json");
let db={users:{},queues:{},orders:[],seq:1};
try{db=Object.assign(db,JSON.parse(fs.readFileSync(DBF,"utf8")))}catch(e){}
// Editable content (admin page changes these). Starts from the sample seed.
db.mess=db.mess||Object.fromEntries(["men","women"].map(h=>[h,Object.fromEntries(["veg","nonveg","special"].map(t=>[t,Array.from({length:7},()=>({...seed.mess[t]}))]))]));
db.menu=db.menu||seed.menu.map(x=>({...x}));db.nextItem=db.nextItem||1000;db.messDay=db.messDay||{};
const save=()=>fs.writeFileSync(DBF,JSON.stringify(db));save();
const MIN_PER_PERSON=1.5,HOSTELS=["men","women"],PREFS=["veg","nonveg","special"],DAYS=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
const send=(res,code,obj)=>{res.writeHead(code,{"Content-Type":"application/json"});res.end(JSON.stringify(obj))};
const body=req=>new Promise(r=>{let d="";req.on("data",c=>{d+=c;if(d.length>2e6)req.destroy()});req.on("end",()=>{try{r(JSON.parse(d||"{}"))}catch(e){r({})}})});
const str=(v,n=120)=>String(v==null?"":v).slice(0,n);
const bearer=req=>(req.headers.authorization||"").replace("Bearer ","");
const user=req=>db.users[bearer(req)];
const queue=o=>db.queues[o]||(db.queues[o]=[]);
const outletView=o=>({...o,q:queue(o.id).length,pending:db.orders.filter(x=>x.outlet===o.id&&x.status!=="collected").length,waitMin:Math.round(queue(o.id).length*MIN_PER_PERSON)});
const ymd=()=>new Date(Date.now()+5.5*3600e3).toISOString().slice(0,10); // IST date
const today=()=>new Date(Date.now()+5.5*3600e3).getUTCDay(); // IST
const isAdmin=req=>req.headers["x-admin-pin"]===staff.admin;
function findToken(uid){for(const o in db.queues){const i=db.queues[o].findIndex(t=>t.uid===uid);
  if(i>=0)return{outlet:o,name:seed.outlets.find(x=>x.id===o).n,pos:i+1,waitMin:Math.round((i+1)*MIN_PER_PERSON)}}return null}
const meView=u=>({user:u,day:DAYS[today()],mess:((db.messDay[u.hostel]||{})[u.pref]||{})[ymd()]||db.mess[u.hostel][u.pref][today()],meals:seed.meals,
  token:findToken(u.id),orders:db.orders.filter(o=>o.uid===u.id).slice(-5).reverse()});

const routes={
 // ---- student profile: no passwords, no VTOP. Device id + name + hostel + mess type ----
 "POST /api/register":async(req,res)=>{const id=bearer(req);if(id.length<8)return send(res,400,{error:"Bad device id"});
  const b=await body(req),name=str(b.name,40).trim();
  if(!name||!HOSTELS.includes(b.hostel)||!PREFS.includes(b.pref))return send(res,400,{error:"Enter your name, hostel and mess type."});
  db.users[id]={id,name,hostel:b.hostel,pref:b.pref,remind:false,...(db.users[id]&&{remind:db.users[id].remind})};save();send(res,200,meView(db.users[id]))},
 "GET /api/me":(req,res)=>{const u=user(req);if(!u)return send(res,401,{error:"Set up your profile"});send(res,200,meView(u))},
 "POST /api/settings":async(req,res)=>{const u=user(req);if(!u)return send(res,401,{});const b=await body(req);
  if(PREFS.includes(b.pref))u.pref=b.pref;if(HOSTELS.includes(b.hostel))u.hostel=b.hostel;if(b.name&&str(b.name,40).trim())u.name=str(b.name,40).trim();
  if(typeof b.remind==="boolean")u.remind=b.remind;save();send(res,200,meView(u))},
 // ---- outlets, menus, queue ----
 "GET /api/outlets":(req,res)=>send(res,200,{outlets:seed.outlets.map(outletView),discover:seed.discover}),
 "GET /api/menu":(req,res,q)=>send(res,200,{menu:db.menu.filter(i=>i.o===q.get("outlet"))}),
 "POST /api/queue/join":async(req,res)=>{const u=user(req);if(!u)return send(res,401,{});const {outlet}=await body(req);
  if(!seed.outlets.some(o=>o.id===outlet))return send(res,400,{error:"Unknown outlet"});
  if(findToken(u.id))return send(res,409,{error:"You are already in a queue. Leave it first."});
  queue(outlet).push({uid:u.id,name:u.name,at:Date.now()});save();send(res,200,{token:findToken(u.id)})},
 "POST /api/queue/leave":(req,res)=>{const u=user(req);if(!u)return send(res,401,{});
  for(const o in db.queues)db.queues[o]=db.queues[o].filter(t=>t.uid!==u.id);save();send(res,200,{ok:true})},
 // ---- pickup orders (delivery intentionally not built) ----
 "POST /api/orders":async(req,res)=>{const u=user(req);if(!u)return send(res,401,{});const {items={}}=await body(req);
  const lines=Object.entries(items).map(([id,n])=>[db.menu.find(i=>i.id==id),Math.min(20,Math.max(0,n|0))]).filter(([i,n])=>i&&n);
  if(!lines.length||new Set(lines.map(([i])=>i.o)).size!==1)return send(res,400,{error:"Order items from exactly one outlet."});
  if(lines.some(([i])=>i.off))return send(res,400,{error:"An item in your cart just sold out. Please check the menu."});
  const o={id:db.seq++,uid:u.id,name:u.name,outlet:lines[0][0].o,items:lines.map(([i,n])=>({n:i.n,qty:n,p:i.p})),
   total:lines.reduce((a,[i,n])=>a+i.p*n,0),status:"placed",at:Date.now()};
  db.orders.push(o);save();send(res,200,{order:o})},
 // ---- outlet staff screen (PIN per outlet) ----
 "GET /api/staff/board":(req,res,q)=>{const o=q.get("outlet");if(staff[o]!==q.get("pin"))return send(res,401,{error:"Wrong PIN"});
  send(res,200,{queue:queue(o).map((t,i)=>({pos:i+1,name:t.name,waitedMin:Math.round((Date.now()-t.at)/6e4)})),
   orders:db.orders.filter(x=>x.outlet===o&&x.status!=="collected")})},
 "POST /api/staff/next":async(req,res)=>{const {outlet,pin}=await body(req);if(staff[outlet]!==pin)return send(res,401,{});
  const t=queue(outlet).shift();save();send(res,200,{called:t||null})},
 "POST /api/staff/order":async(req,res)=>{const {outlet,pin,id,status}=await body(req);if(staff[outlet]!==pin)return send(res,401,{});
  const o=db.orders.find(x=>x.id===id&&x.outlet===outlet);if(!o||!["preparing","ready","collected"].includes(status))return send(res,400,{});
  o.status=status;save();send(res,200,{order:o})},
 // ---- admin: hostel mess menus + every outlet's menu ----
 "GET /api/admin/content":(req,res)=>isAdmin(req)?send(res,200,{mess:db.mess,messDates:Object.fromEntries(Object.entries(db.messDay).map(([h,t])=>[h,Object.fromEntries(Object.entries(t).map(([k,v])=>{const d=Object.keys(v).sort();return[k,[d[0],d[d.length-1],d.length]]}))])),menu:db.menu,outlets:seed.outlets,days:DAYS}):send(res,401,{error:"Wrong admin PIN"}),
 "POST /api/admin/mess":async(req,res)=>{if(!isAdmin(req))return send(res,401,{});const b=await body(req);
  if(!HOSTELS.includes(b.hostel)||!PREFS.includes(b.type)||!b.meals)return send(res,400,{error:"Bad request"});
  const m={b:str(b.meals.b,200),l:str(b.meals.l,200),s:str(b.meals.s,200),d:str(b.meals.d,200)},arr=db.mess[b.hostel][b.type];
  if(b.day==="all")for(let i=0;i<7;i++)arr[i]={...m};else arr[b.day|0]=m;save();send(res,200,{ok:true})},
 "POST /api/admin/messmonth":async(req,res)=>{if(!isAdmin(req))return send(res,401,{});const b=await body(req);
  if(!HOSTELS.includes(b.hostel)||!PREFS.includes(b.type)||!b.days||typeof b.days!=="object")return send(res,400,{error:"Bad request"});
  const t=((db.messDay[b.hostel]=db.messDay[b.hostel]||{})[b.type]=db.messDay[b.hostel][b.type]||{});let n=0;
  for(const [k,m] of Object.entries(b.days)){if(!/^\d{4}-\d{2}-\d{2}$/.test(k)||!m||n>=62)continue;
   t[k]={b:str(m.b,1500),l:str(m.l,1500),s:str(m.s,1500),d:str(m.d,1500)};n++}
  save();send(res,200,{ok:true,count:n})},
 "POST /api/admin/item":async(req,res)=>{if(!isAdmin(req))return send(res,401,{});const b=await body(req);
  if(!seed.outlets.some(o=>o.id===b.o)||!str(b.n).trim())return send(res,400,{error:"Outlet and item name required"});
  const f={o:b.o,n:str(b.n,60).trim(),p:Math.min(5000,Math.max(0,Math.round(+b.p)||0)),e:str(b.e||"🍽️",8),...(str(b.c).trim()?{c:str(b.c,40).trim()}:{}),...(b.v?{v:1}:{}),...(b.off?{off:1}:{})};
  const i=db.menu.findIndex(x=>x.id===b.id);
  if(i>=0)db.menu[i]={id:b.id,...f};else db.menu.push({id:db.nextItem++,...f});save();send(res,200,{menu:db.menu})},
 "POST /api/admin/item/delete":async(req,res)=>{if(!isAdmin(req))return send(res,401,{});const {id}=await body(req);
  db.menu=db.menu.filter(x=>x.id!==id);save();send(res,200,{menu:db.menu})}
};
const MIME={".html":"text/html",".js":"text/javascript",".css":"text/css",".json":"application/json",".webmanifest":"application/manifest+json",".svg":"image/svg+xml",".png":"image/png"};
http.createServer(async(req,res)=>{
 const u=new URL(req.url,"http://x"),h=routes[req.method+" "+u.pathname];
 if(h){try{return await h(req,res,u.searchParams)}catch(e){console.error(e);return send(res,500,{error:"Server error"})}}
 const f=path.join(__dirname,"public",u.pathname==="/"?"index.html":u.pathname.replace(/\.\./g,""));
 fs.readFile(f,(e,d)=>{if(e){res.writeHead(404);return res.end("Not found")}res.writeHead(200,{"Content-Type":MIME[path.extname(f)]||"application/octet-stream","Cache-Control":"no-cache"});res.end(d)})
}).listen(PORT,()=>console.log(`QORA on http://localhost:${PORT}\n  student app: /   outlet screen: /outlet.html   admin (menus): /admin.html`));
